package com.train.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.train.model.Passenger;
import com.train.service.PassengerService;
@RestController
@RequestMapping("passenger")
public class PassengerController {

	@Autowired
	PassengerService Service;
	@PostMapping("add")
	public Passenger create(@RequestBody Passenger add) {
		return Service.add(add);
   	}
	@GetMapping("view")
	public List<Passenger>getAll()	{
		return Service.getAll();
	}
	}
