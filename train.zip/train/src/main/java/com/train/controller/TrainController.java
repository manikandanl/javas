package com.train.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.train.model.Train;
import com.train.service.TrainService;
@RestController
@RequestMapping("train")
public class TrainController {
    @Autowired
	TrainService Service;
    @PostMapping("add")
	public Train create(@RequestBody Train add) {
//    	List<Passenger> passengers = add.getPassenger();
//    	for(Passenger passenger : passengers) {
//    		System.err.println("--------"+passenger);
////    		passenger 
//    	}
		return Service.add(add);
	}
    @GetMapping("view")
	public List<Train> getAll(){
		return Service.getAll();

    }
    
    @RequestMapping(value= "view/{id}", method= RequestMethod.GET)
	public Train getEmployeeById(@PathVariable Long id) throws Exception{
    Optional<Train> trs =  Service.getById(id);
    if(!trs.isPresent())
        throw new Exception("not find employeeid- " + id);
        return trs.get();
}
}


