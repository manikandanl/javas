package com.train.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.train.model.Train;
import com.train.repository.TrainRepository;
@Component
public class TrainService {
	@Autowired
   TrainRepository Repository;
	
	public Train add(Train insert) {
		return Repository.save(insert);
	}
    public List<Train> getAll(){
		return Repository.findAll();
    }
    public Optional<Train> getById(Long id){
		return Repository.findById(id);
    	
    }
}
