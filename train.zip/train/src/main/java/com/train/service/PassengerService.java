package com.train.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.train.model.Passenger;
import com.train.repository.PassengerRepository;
@Component
public class PassengerService {
    @Autowired
	PassengerRepository Repository;
	
	public Passenger add(Passenger insert) {
		return Repository.save(insert);
	}
	public List <Passenger> getAll(){
		return Repository.findAll();
	}
}
